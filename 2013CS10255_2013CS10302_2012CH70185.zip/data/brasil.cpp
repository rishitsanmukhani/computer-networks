http://guanabara.rederio.br/cgi-bin/nph-traceroute?target=129.132.19.216&function=traceroute

Proxy provided a private IPv4 address for your web client/browser, HTTP_X_FORWARDED_FOR=10.251.216.167
Executing exec(traceroute -m 30 -q 3 129.132.19.216 140)
traceroute to 129.132.19.216 (129.132.19.216), 30 hops max, 140 byte packets
 1  200.20.94.110 (200.20.94.110)  4.322 ms  4.395 ms  4.470 ms
 2  200.20.96.73 (200.20.96.73)  0.715 ms *  0.823 ms
 3  xe-0-3-1.ar2.gig1.gblx.net (64.214.61.249)  0.455 ms  0.455 ms  0.453 ms
 4  po2.ar3.MIA2.gblx.net (67.17.68.234)  101.905 ms * po3-20G.ar3.MIA2.gblx.net (67.17.75.66)  101.689 ms
 5  ae5.edge2.miami2.level3.net (4.68.111.121)  132.822 ms  132.823 ms  132.736 ms
 6  ae-5-5.car1.Geneva1.Level3.net (4.69.137.81)  243.663 ms  243.747 ms  243.995 ms
 7  ae-5-5.car1.Geneva1.Level3.net (4.69.137.81)  243.841 ms  243.791 ms  243.398 ms
 8  DANTE.car1.Geneva1.Level3.net (213.242.73.74)  208.556 ms  208.447 ms  208.285 ms
 9  swiCE3-P23.switch.ch (130.59.36.210)  208.285 ms  208.362 ms  208.504 ms
10  swiCE1-B3.switch.ch (130.59.38.81)  208.852 ms  208.780 ms  208.763 ms
11  swiEZ3-100GE-0-1-0-0.switch.ch (130.59.36.94)  213.120 ms  213.526 ms  213.109 ms
12  rou-gw-rz-tengig-to-switch.ethz.ch (192.33.92.1)  213.465 ms  213.830 ms  213.461 ms
13  rou-fw-rz-rz-gw.ethz.ch (192.33.92.169)  213.203 ms  213.215 ms  213.409 ms
14  * * *
15  * * *
16  * * *
17  * * *
18  * * *
19  * * *
20  * * *
21  * * *
22  * * *
23  * * *
24  * * *
25  * * *
26  * * *
27  * * *
28  * * *
29  * * *
30  * * *
traceroute -m 30 -q 3 129.132.19.216 140 took 35secs. Total time=36secs.




Proxy provided a private IPv4 address for your web client/browser, HTTP_X_FORWARDED_FOR=10.251.216.167
Executing exec(traceroute -m 30 -q 3 103.27.9.20 140)
traceroute to 103.27.9.20 (103.27.9.20), 30 hops max, 140 byte packets
 1  200.20.94.110 (200.20.94.110)  0.319 ms  0.389 ms  0.466 ms
 2  200.20.96.73 (200.20.96.73)  3.436 ms  3.438 ms  3.423 ms
 3  xe-0-3-1.ar2.gig1.gblx.net (64.214.61.249)  0.495 ms  0.495 ms  0.491 ms
 4  po5.ar1.MIA2.gblx.net (67.16.148.102)  111.080 ms po4-20G.ar1.MIA2.gblx.net (67.16.134.218)  111.332 ms  111.339 ms
 5  ix-2-3-1-0.tcore1.MLN-Miami.as6453.net (66.110.9.61)  101.447 ms  101.463 ms  101.458 ms
 6  if-7-2.tcore1.AEQ-Ashburn.as6453.net (66.198.154.177)  214.805 ms  214.430 ms  213.897 ms
 7  * * if-2-2.tcore2.AEQ-Ashburn.as6453.net (216.6.87.1)  214.819 ms
 8  if-3-2.thar2.NJY-Newark.as6453.net (216.6.87.10)  218.721 ms if-11-3.thar2.NJY-Newark.as6453.net (216.6.87.242)  217.360 ms *
 9  if-2-2.tcore2.L78-London.as6453.net (80.231.131.1)  213.832 ms  214.230 ms if-1-3.thar1.NJY-Newark.as6453.net (216.6.57.1)  218.449 ms
10  if-7-2.tcore1.L78-London.as6453.net (66.198.70.26)  219.171 ms *  216.891 ms
11  if-2-2.tcore2.L78-London.as6453.net (80.231.131.1)  216.223 ms 80.231.200.30 (80.231.200.30)  305.105 ms if-2-2.tcore2.L78-London.as6453.net (80.231.131.1)  216.983 ms
12  if-9-2.tcore2.WYN-Marseille.as6453.net (80.231.200.13)  215.940 ms  216.027 ms *
13  80.231.200.30 (80.231.200.30)  305.093 ms  307.545 ms  305.028 ms
14  10.119.234.161 (10.119.234.161)  403.790 ms * *
15  14.140.210.22.static-Delhi-vsnl.net.in (14.140.210.22)  331.704 ms  329.503 ms *
16  10.119.234.161 (10.119.234.161)  405.207 ms  407.341 ms *
17  * * *
18  * * *
19  * * *
20  * * *
21  * * *
22  * * *
23  * * *
24  * * *
25  * * *
26  * * *
27  * * *
28  * * *
29  * * *
30  * * *
traceroute -m 30 -q 3 103.27.9.20 140 took 76secs. Total time=81secs.




Proxy provided a private IPv4 address for your web client/browser, HTTP_X_FORWARDED_FOR=10.251.216.167
Executing exec(traceroute -m 30 -q 3 129.97.208.23 140)
traceroute to 129.97.208.23 (129.97.208.23), 30 hops max, 140 byte packets
 1  200.20.94.110 (200.20.94.110)  0.327 ms  0.396 ms  0.471 ms
 2  200.20.96.73 (200.20.96.73)  0.643 ms  0.785 ms  0.791 ms
 3  xe-0-3-1.ar2.gig1.gblx.net (64.214.61.249)  8.267 ms  8.272 ms  8.270 ms
 4  * po2.ar3.MIA2.gblx.net (67.17.68.234)  107.676 ms  107.751 ms
 5  ae5.edge2.miami2.level3.net (4.68.111.121)  132.754 ms  132.849 ms  132.854 ms
 6  * ae-1-3501.ear3.NewYork1.Level3.net (4.69.150.202)  162.903 ms *
 7  ALLSTREAM-I.ear3.NewYork1.Level3.net (4.28.130.30)  165.701 ms  165.669 ms  165.909 ms
 8  10ge4-11.hcap9-tor.bb.allstream.net (199.212.169.202)  180.760 ms  180.863 ms  180.878 ms
 9  10ge4-11.hcap9-tor.bb.allstream.net (199.212.169.202)  180.455 ms  179.952 ms  180.699 ms
10  216-191-167-38.dedicated.allstream.net (216.191.167.38)  136.951 ms  137.162 ms  137.142 ms
11  * * *
12  * * *
13  * * *
14  * * *
15  wms.uwaterloo.ca (129.97.208.23)  137.073 ms  137.128 ms *
16  * * *
17  wms.uwaterloo.ca (129.97.208.23)  136.629 ms  137.024 ms  136.941 ms
18  * * *
19  wms.uwaterloo.ca (129.97.208.23)  137.284 ms  136.890 ms  137.315 ms
20  * * *
21  wms.uwaterloo.ca (129.97.208.23)  137.311 ms  136.875 ms *
22  * * *
23  wms.uwaterloo.ca (129.97.208.23)  137.170 ms  137.154 ms  137.358 ms
24  * * *
25  wms.uwaterloo.ca (129.97.208.23)  136.924 ms  136.902 ms  137.100 ms
26  * * *
27  wms.uwaterloo.ca (129.97.208.23)  136.842 ms  137.030 ms  137.006 ms
28  * * *
29  wms.uwaterloo.ca (129.97.208.23)  136.891 ms  136.861 ms  137.403 ms
30  * * *
traceroute -m 30 -q 3 129.97.208.23 140 took 28secs. Total time=30secs.





Proxy provided a private IPv4 address for your web client/browser, HTTP_X_FORWARDED_FOR=10.251.216.167
Executing exec(traceroute -m 30 -q 3 137.158.158.44 140)
traceroute to 137.158.158.44 (137.158.158.44), 30 hops max, 140 byte packets
 1  200.20.94.110 (200.20.94.110)  0.364 ms  0.439 ms  0.522 ms
 2  200.20.96.73 (200.20.96.73)  2.074 ms  2.081 ms  2.081 ms
 3  xe-0-3-1.ar2.gig1.gblx.net (64.214.61.249)  0.487 ms  0.486 ms  0.483 ms
 4  ae0-0-40G.ar2.NYC1.gblx.net (67.16.151.74)  124.566 ms  116.522 ms  116.528 ms
 5  208.51.134.114 (208.51.134.114)  117.661 ms  118.284 ms  117.380 ms
 6  be2057.ccr42.jfk02.atlas.cogentco.com (154.54.80.177)  117.688 ms be2056.ccr41.jfk02.atlas.cogentco.com (154.54.44.217)  109.505 ms *
 7  * te0-3-0-17.ccr41.iad02.atlas.cogentco.com (154.54.11.173)  131.372 ms be2122.ccr41.atl01.atlas.cogentco.com (154.54.24.193)  130.993 ms
 8  be2112.ccr41.dca01.atlas.cogentco.com (154.54.7.157)  127.266 ms be2113.ccr42.dca01.atlas.cogentco.com (154.54.24.221)  134.586 ms be2112.ccr41.dca01.atlas.cogentco.com (154.54.7.157)  128.360 ms
 9  be2149.ccr42.jfk02.atlas.cogentco.com (154.54.31.126)  127.988 ms  126.956 ms  127.758 ms
10  be2317.ccr41.lon13.atlas.cogentco.com (154.54.30.186)  202.721 ms  205.435 ms *
11  * * be2163.ccr22.lon01.atlas.cogentco.com (130.117.50.201)  203.261 ms
12  be2417.rcr11.b015533-1.lon01.atlas.cogentco.com (154.54.38.14)  194.087 ms be2426.rcr11.b015533-1.lon01.atlas.cogentco.com (154.54.38.190)  198.383 ms  196.951 ms
13  149.14.80.210 (149.14.80.210)  197.986 ms  197.401 ms  198.493 ms
14  ae1-1001-cpt1-ir1-i.tenet.ac.za (196.32.209.170)  341.052 ms  342.299 ms  342.106 ms
15  be4-cpt1-p1.tenet.ac.za (155.232.6.65)  349.073 ms  347.362 ms  347.800 ms
16  te0-0-0-1-cpt2-p1-n.tenet.ac.za (155.232.6.190)  349.490 ms  348.979 ms  348.595 ms
17  te0-12-0-6-cpt2-p1-n.tenet.ac.za (155.232.6.233)  342.897 ms  342.604 ms  343.813 ms
18  155.232.32.14 (155.232.32.14)  344.203 ms  344.410 ms  343.827 ms
19  * * *
20  * * *
21  * * *
22  * * *
23  * * *
24  * * *
25  * * *
26  * * *
27  * * *
28  * * *
29  * * *
30  * * *
traceroute -m 30 -q 3 137.158.158.44 140 took 73secs. Total time=74secs.