http://services.utanet.at/traceroute/index.html
Ergebnis: traceroute to 173.252.88.66
1 213.90.34.1 (213.90.34.1) 0.556 ms 0.517 ms 0.498 ms 
2 213.90.1.20 (213.90.1.20) 0.902 ms 0.771 ms 0.844 ms 
3 wat1-15-93.net.uta.at (62.218.15.93) 0.946 ms 0.710 ms 0.855 ms 
4 c76wat2-tge12-1.net.uta.at (212.152.192.166) 1.279 ms 0.964 ms 1.546 ms 
5 * * * 
6 fra36-core-1.bundle-ether7.tele2.net (130.244.206.28) 13.379 ms 13.777 ms 13.375 ms 
7 ams-core-2.bundle-ether4.tele2.net (130.244.64.201) 20.406 ms 21.263 ms 20.285 ms 
8 ams13-peer-1.ae8-unit0.tele2.net (130.244.38.233) 19.792 ms 19.906 ms 19.823 ms 
9 130.244.200.32 (130.244.200.32) 19.776 ms 20.514 ms 19.756 ms 
10 ae1.bb01.ams2.tfbnw.net (31.13.29.86) 19.639 ms 19.756 ms 19.723 ms 
MPLS Label=689540 CoS=6 TTL=1 S=0 
11 ae3.bb02.bos2.tfbnw.net (204.15.23.61) 99.843 ms 100.091 ms 100.561 ms 
MPLS Label=622148 CoS=6 TTL=1 S=0 
12 be10.bb01.ewr2.tfbnw.net (204.15.23.59) 133.592 ms 134.283 ms 133.420 ms 
MPLS Label=37084 CoS=6 TTL=1 S=0 
13 be44.bb01.iad3.tfbnw.net (31.13.26.1) 134.207 ms 134.201 ms 134.572 ms 
MPLS Label=33210 CoS=6 TTL=1 S=0 
14 be4.bb02.atn1.tfbnw.net (31.13.27.14) 133.791 ms 134.240 ms 133.823 ms 
MPLS Label=31750 CoS=6 TTL=1 S=0 
15 ae1.dr01.atn2.tfbnw.net (31.13.25.103) 133.178 ms 147.792 ms 133.203 ms 
16 * * * 
17 * * * 
18 * * * 
19 * * * 
20 * * * 
21 edge-star-shv-03-atn1.facebook.com (173.252.88.66) 126.745 ms 126.827 ms 126.769 ms 

http://services.truteq.com/cgi-bin/nph-traceroute?173.252.88.66

Traceroute

Back to the Truteq Looking Glass (ping, traceroute, DNS lookup and NTP server checking)
Result for traceroute to 173.252.88.66:

traceroute to 173.252.88.66 (173.252.88.66), 30 hops max, 38 byte packets
 1  cisrb1-net109-64.posix.co.za (160.124.109.126)  0.400 ms  0.317 ms  0.205 ms
 2  cisldn1-cisrbc1.posix.co.za (160.124.1.2)  169.115 ms  169.028 ms  168.808 ms
 3  gi8-14.mag02.lon02.atlas.cogentco.com (149.6.149.9)  168.856 ms  184.165 ms  182.593 ms
 4  te0-0-0-9.ccr21.lon02.atlas.cogentco.com (154.54.60.145)  180.838 ms te0-7-0-7.ccr21.lon02.atlas.cogentco.com (154.54.60.149)  171.917 ms te0-0-0-9.ccr21.lon02.atlas.cogentco.com (154.54.60.145)  178.630 ms
 5  be2329.ccr22.lon01.atlas.cogentco.com (130.117.49.89)  202.723 ms be2328.ccr21.lon01.atlas.cogentco.com (130.117.49.85)  169.459 ms be2329.ccr22.lon01.atlas.cogentco.com (130.117.49.89)  193.203 ms
 6  te0-0-2-2.rcr11.b023101-0.lon01.atlas.cogentco.com (130.117.51.137)  181.398 ms te0-0-2-0.rcr11.b023101-0.lon01.atlas.cogentco.com (130.117.51.73)  189.904 ms  183.131 ms
 7  abovenet.lon09.atlas.cogentco.com (130.117.14.182)  190.088 ms  191.759 ms  180.317 ms
 8  ae5.mpr2.lhr2.uk.zip.zayo.com (64.125.21.9)  201.814 ms  169.492 ms  169.355 ms
 9  v113.ae29.cr1.lga5.us.zip.zayo.com (64.125.30.108)  242.805 ms  239.255 ms  239.029 ms
10  ae2.er3.lga5.us.zip.zayo.com (64.125.31.214)  238.752 ms  238.994 ms  238.789 ms
11  128.177.165.234.IPYX-100687-870-ZYO.zip.zayo.com (128.177.165.234)  237.554 ms  237.430 ms  237.539 ms
12  be1.bb01.lga1.tfbnw.net (204.15.20.190)  267.531 ms  267.607 ms  267.269 ms
13  be29.bb02.dca1.tfbnw.net (74.119.78.164)  267.292 ms ae15.bb03.dca1.tfbnw.net (74.119.76.20)  243.973 ms be29.bb02.dca1.tfbnw.net (74.119.78.164)  268.212 ms
14  ae10.pr01.lax1.tfbnw.net (31.13.24.176)  291.674 ms ae22.bb03.atn1.tfbnw.net (31.13.25.4)  283.102 ms be23.bb02.atn1.tfbnw.net (31.13.25.0)  266.214 ms
15  ae3.dr06.atn1.tfbnw.net (74.119.76.99)  266.764 ms ae2.dr08.atn1.tfbnw.net (74.119.76.95)  277.061 ms ae1.dr07.atn1.tfbnw.net (74.119.76.73)  265.333 ms
16  * * *
17  * * *
18  * * *
19  * * *
20  * * *
21  edge-star-shv-03-atn1.facebook.com (173.252.88.66)  265.636 ms  265.477 ms  265.563 ms

Completed in 87.26 seconds, 0% cpu


http://www.snlink.net/



query	ip or name address
	 trace
	 ping
   
please email questions or comments to noc@silesnet.net


traceroute to 173.252.88.66 (173.252.88.66), 30 hops max, 60 byte packets
 1  78-157-167-1.silesnet.net (78.157.167.1) [AS43709]  8.808 ms  9.646 ms  10.473 ms
 2  78-157-167-206.silesnet.net (78.157.167.206) [AS43709]  0.105 ms  0.096 ms  0.089 ms
 3  cz-prg-asbr2-xe-4-1-1-v1517-dialtelecom.cz (82.113.38.105) [AS29208]  6.337 ms  6.314 ms  6.320 ms
 4  cz-prg-76kkk-po5.dialtelecom.cz (82.119.246.237) [AS29208]  15.523 ms  15.734 ms  15.713 ms
 5  82.119.246.229 (82.119.246.229) [AS29208]  15.617 ms  15.676 ms  15.756 ms
 6  de-ffm-asbr3-be2-dialtelecom.cz (82.119.245.186) [AS29208]  15.655 ms  15.636 ms  15.705 ms
 7  ae9.pr02.fra2.tfbnw.net (103.4.96.132) [AS32934]  15.537 ms  15.489 ms  15.465 ms
 8  be3.bb01.fra2.tfbnw.net (31.13.27.207) [AS32934]  130.598 ms be3.bb02.fra2.tfbnw.net (31.13.27.209) [AS32934]  136.902 ms  136.351 ms
 9  xe-10-3-0.br01.snc1.tfbnw.net (74.119.76.10) [AS32934]  22.059 ms  22.051 ms  22.041 ms
10  ae9.bb01.lhr2.tfbnw.net (31.13.30.211) [AS32934]  26.888 ms ae9.bb02.lhr2.tfbnw.net (204.15.22.251) [AS32934/AS10753]  27.531 ms ae9.bb01.lhr2.tfbnw.net (31.13.30.211) [AS32934]  26.615 ms
11  be11.bb01.ewr2.tfbnw.net (31.13.30.98) [AS32934]  131.211 ms be23.bb01.lga1.tfbnw.net (74.119.78.102) [AS32934]  130.705 ms be10.bb01.ewr2.tfbnw.net (204.15.23.59) [AS32934/AS10753]  137.827 ms
12  be44.bb02.iad3.tfbnw.net (31.13.26.5) [AS32934]  137.802 ms be44.bb01.iad3.tfbnw.net (31.13.26.1) [AS32934]  131.161 ms  133.145 ms
13  ae3.bb04.atn1.tfbnw.net (31.13.27.16) [AS32934]  130.642 ms  137.416 ms  130.766 ms
14  ae2.dr06.atn1.tfbnw.net (74.119.76.91) [AS32934]  155.824 ms ae1.dr01.atn2.tfbnw.net (31.13.25.103) [AS32934]  132.688 ms ae2.dr06.atn1.tfbnw.net (74.119.76.91) [AS32934]  155.796 ms
15  * * *
16  * * *
17  * * *
18  * * *
19  * * *
20  edge-star-shv-03-atn1.facebook.com (173.252.88.66) [AS32934]  131.708 ms  130.462 ms  135.557 ms
20  edge-star-shv-03-atn1.facebook.com (173.252.88.66) [AS32934]  131.708 ms  130.462 ms  135.557 ms


http://www.tera-byte.com/cgi-bin/nph-trace?173.252.88.66

Traceroute Output

FROM www.tera-byte.com TO 173.252.88.66
traceroute to 173.252.88.66 (173.252.88.66) from 216.234.191.172, 30 hops max, 40 byte packets
 1  cat6509-vlan2.edm.tera-byte.com (216.234.161.1)  0.498 ms
 2  *
 3  edtnabxmgr01.bb.telus.com (205.233.111.139)  1.187 ms
 4  CHCGILDTCI01.bb.telus.com (75.154.223.244)  39.522 ms
 5  ae5.pr02.ord1.tfbnw.net (103.4.96.48)  33.792 ms
 6  be20.bb01.ord1.tfbnw.net (74.119.77.134)  46.649 ms
 7  ae7.bb03.atn1.tfbnw.net (31.13.28.28)  46.398 ms
 8  ae0.dr03.atn2.tfbnw.net (31.13.26.69)  46.152 ms
 9  *
10  *
11  *
12  *
13  *
14  edge-star-shv-03-atn1.facebook.com (173.252.88.66)  52.790 ms
Conduct another search


http://traceroute.dsvr.co.uk/cgi-bin/trace.pl?t=173.252.88.66

Traceroute Gateway

at Designer Servers Ltd
Version: v1.2 Date: 14-Oct-2001 Copyright: (c) Gabor Szabo @ Multiple Traceroute Gateway
Other Traceroute Gateways

 1  host-212-69-210-4.no-dns.as5587.net (212.69.210.4)  0.000 ms  0.000 ms  0.000 ms
 2  host-213-253-141-28.no-dns.as5587.net (213.253.141.28)  0.000 ms  0.000 ms  10.000 ms
 3  v1124.core1.lon1.he.net (216.66.83.113)  10.000 ms  10.000 ms  10.000 ms
 4  10ge2-9.core1.lon2.he.net (72.52.92.222)  10.001 ms  20.000 ms  10.000 ms
 5  linx.br01.lhr1.tfbnw.net (195.66.225.69)  0.000 ms  10.000 ms  10.001 ms
 6  ae1.bb01.lhr2.tfbnw.net (31.13.30.174)  0.000 ms ae1.bb02.lhr2.tfbnw.net (31.13.30.198)  10.000 ms ae11.bb01.lhr2.tfbnw.net (74.119.78.74)  0.000 ms
 7  be11.bb01.ewr2.tfbnw.net (31.13.30.98)  110.001 ms  100.001 ms be14.bb01.ewr2.tfbnw.net (74.119.78.142)  100.002 ms
 8  be44.bb02.iad3.tfbnw.net (31.13.26.5)  100.001 ms  100.001 ms  100.002 ms
 9  be4.bb02.atn1.tfbnw.net (31.13.27.14)  110.001 ms ae3.bb04.atn1.tfbnw.net (31.13.27.16)  100.001 ms be4.bb02.atn1.tfbnw.net (31.13.27.14)  100.001 ms
10  ae3.dr05.atn1.tfbnw.net (74.119.76.97)  100.002 ms ae1.dr08.atn1.tfbnw.net (74.119.76.81)  100.002 ms ae3.dr08.atn1.tfbnw.net (74.119.76.103)  100.001 ms
11  * * *
12  * * *
13  * * *
14  * * *
15  * * *
16  edge-star-shv-03-atn1.facebook.com (173.252.88.66)  100.002 ms  100.001 ms  100.002 ms
Please type in the IP address or the full name of the machine you want to Traceroute to


http://guanabara.rederio.br/cgi-bin/nph-traceroute?target=173.252.88.66&function=traceroute

Proxy provided a private IPv4 address for your web client/browser, HTTP_X_FORWARDED_FOR=10.251.216.167
Executing exec(traceroute -m 30 -q 3 173.252.88.66 140)
traceroute to 173.252.88.66 (173.252.88.66), 30 hops max, 140 byte packets
 1  200.20.94.110 (200.20.94.110)  0.346 ms  0.410 ms  0.486 ms
 2  200.20.96.73 (200.20.96.73)  1.876 ms  1.872 ms  1.947 ms
 3  200.20.96.5 (200.20.96.5)  0.797 ms  0.841 ms  0.892 ms
 4  rederio-rj.bkb.rnp.br (200.143.254.138)  0.363 ms  0.371 ms  0.369 ms
 5  rj-sp2-oi.bkb.rnp.br (200.143.253.221)  8.004 ms sp-rj-nau.bkb.rnp.br (200.143.252.69)  8.208 ms  8.208 ms
 6  sp-sp2.bkb.rnp.br (200.143.253.37)  8.049 ms  7.929 ms  8.029 ms
 7  be35.bb01.iad3.tfbnw.net (204.15.22.112)  186.298 ms ae27.bb01.atl1.tfbnw.net (173.252.64.84)  158.350 ms be18.bb02.iad3.tfbnw.net (31.13.31.252)  186.412 ms
 8  be35.bb01.iad3.tfbnw.net (204.15.22.112)  187.082 ms be7.bb01.ord1.tfbnw.net (31.13.27.23)  181.611 ms be14.bb01.ord2.tfbnw.net (31.13.24.15)  181.420 ms
 9  ae1.dr08.atn1.tfbnw.net (74.119.76.81)  198.111 ms be4.bb02.atn1.tfbnw.net (31.13.27.14)  188.205 ms  188.218 ms
10  ae1.dr03.atn2.tfbnw.net (31.13.26.75)  186.520 ms ae0.dr03.atn2.tfbnw.net (31.13.26.69)  182.078 ms ae3.dr06.atn1.tfbnw.net (74.119.76.99)  188.312 ms
11  * * *
12  * * *
13  * * *
14  * * *
15  edge-star-shv-03-atn1.facebook.com (173.252.88.66)  185.987 ms * *
traceroute -m 30 -q 3 173.252.88.66 140 took 26secs. Total time=26secs.