Traceroute server : http://www.tera-byte.com/cgi-bin/nph-trace?129.132.19.216

FROM www.tera-byte.com TO 129.132.19.216
traceroute to 129.132.19.216 (129.132.19.216) from 216.234.191.172, 30 hops max, 40 byte packets
 1  cat6509-vlan2.edm.tera-byte.com (216.234.161.1)  0.389 ms
 2  *
 3  tcore3-edmonton_be1.net.bell.ca (64.230.119.232)  62.548 ms
 4  tcore4-calgaryqa_tengige0-15-0-9.net.bell.ca (64.230.77.105)  66.912 ms
 5  tcore4-toronto12_pos0-0-2-0.net.bell.ca (64.230.144.54)  62.689 ms
 6  Ncore3-montrealak_pos0-15-0-0.net.bell.ca (64.230.147.125)  65.856 ms
 7  newcore1-newyork83_so2-0-0.net.bell.ca (64.230.187.137)  63.790 ms
 8  bx6-newyork83_xe3-0-0.net.bell.ca (64.230.187.158)  61.150 ms
 9  nyiix.bb.ip-plus.net (198.32.160.176)  72.055 ms
10  i68geb-025-ten0-0-0-8.bb.ip-plus.net (138.187.159.18)  153.574 ms
11  i68cix-015-bun1.bb.ip-plus.net (138.187.129.65)  153.235 ms
12  *
13  swiCE1-B3.switch.ch (130.59.38.81)  151.287 ms
14  swiEZ3-100GE-0-1-0-0.switch.ch (130.59.36.94)  154.581 ms
15  rou-gw-rz-tengig-to-switch.ethz.ch (192.33.92.1)  154.601 ms
16  rou-fw-rz-rz-gw.ethz.ch (192.33.92.169)  156.110 ms
17  *
18  *
19  *
20  *
21  *
22  *
23  *
24  *
25  *
26  *
27  *
28  *
29  *
30  *


FROM www.tera-byte.com TO 129.97.208.23
traceroute to 129.97.208.23 (129.97.208.23) from 216.234.191.172, 30 hops max, 40 byte packets
 1  cat6509-vlan2.edm.tera-byte.com (216.234.161.1)  0.468 ms
 2  *
 3  tcore3-edmonton_be1.net.bell.ca (64.230.119.232)  20.848 ms
 4  tcore4-vancouver_tengige0-15-0-5.net.bell.ca (64.230.77.109)  17.628 ms
 5  bx4-vancouver_xe2-1-0.net.bell.ca (64.230.183.110)  15.618 ms
 6  *
 7  10ge4-11.hcap9-tor.bb.allstream.net (199.212.169.202)  51.280 ms
 8  10ge4-11.hcap9-tor.bb.allstream.net (199.212.169.202)  50.842 ms
 9  216-191-167-38.dedicated.allstream.net (216.191.167.38)  52.789 ms
10  *
11  *
12  *
13  *
14  wms.uwaterloo.ca (129.97.208.23)  52.882 ms
15  *
16  wms.uwaterloo.ca (129.97.208.23)  53.135 ms
17  *
18  wms.uwaterloo.ca (129.97.208.23)  52.904 ms
19  *
20  wms.uwaterloo.ca (129.97.208.23)  53.073 ms
21  *
22  wms.uwaterloo.ca (129.97.208.23)  53.140 ms
23  *
24  wms.uwaterloo.ca (129.97.208.23)  53.333 ms
25  *
26  wms.uwaterloo.ca (129.97.208.23)  52.960 ms
27  *
28  wms.uwaterloo.ca (129.97.208.23)  53.025 ms
29  *
30  wms.uwaterloo.ca (129.97.208.23)  53.304 ms


FROM www.tera-byte.com TO 103.27.9.20
traceroute to 103.27.9.20 (103.27.9.20) from 216.234.191.172, 30 hops max, 40 byte packets
 1  cat6509-vlan2.edm.tera-byte.com (216.234.161.1)  0.415 ms
 2  *
 3  tcore3-edmonton_be1.net.bell.ca (64.230.119.232)  21.050 ms
 4  tcore4-vancouver_tengige0-15-0-5.net.bell.ca (64.230.77.109)  16.490 ms
 5  bx4-vancouver_xe2-1-0.net.bell.ca (64.230.183.110)  15.678 ms
 6  if-4-0-1.core3.VCW-Vancouver.as6453.net (64.86.115.13)  58.537 ms
 7  if-5-1-0.core1.00S-Seattle.as6453.net (66.110.25.9)  52.899 ms
 8  if-9-3-3-0.tcore2.CT8-Chicago.as6453.net (64.86.124.34)  295.353 ms
 9  if-22-2.tcore1.CT8-Chicago.as6453.net (64.86.79.2)  297.042 ms
10  if-12-6.tcore2.NYY-New-York.as6453.net (216.6.99.45)  293.763 ms
11  if-20-2.tcore2.L78-London.as6453.net (216.6.99.14)  296.119 ms
12  if-9-2.tcore2.WYN-Marseille.as6453.net (80.231.200.13)  292.881 ms
13  if-2-2.tcore1.WYN-Marseille.as6453.net (80.231.217.1)  288.903 ms
14  if-9-5.tcore1.MLV-Mumbai.as6453.net (80.231.217.18)  296.777 ms
15  if-7-2.tcore1.CXR-Chennai.as6453.net (180.87.36.34)  290.535 ms
16  180.87.36.10 (180.87.36.10)  286.613 ms
17  *
18  14.140.210.22.static-Delhi-vsnl.net.in (14.140.210.22)  313.849 ms
19  *
20  *
21  *
22  *
23  *
24  *
25  *
26  *
27  *
28  *
29  *
30  *

FROM www.tera-byte.com TO 137.158.158.44
traceroute to 137.158.158.44 (137.158.158.44) from 216.234.191.172, 30 hops max, 40 byte packets
 1  cat6509-vlan2.edm.tera-byte.com (216.234.161.1)  0.417 ms
 2  *
 3  tcore3-edmonton_be1.net.bell.ca (64.230.119.232)  25.929 ms
 4  tcore4-vancouver_tengige0-15-0-5.net.bell.ca (64.230.77.109)  21.146 ms
 5  tcore3-seattle_hundredgige0-9-0-0.net.bell.ca (64.230.79.96)  19.807 ms
 6  bx4-seattle_ae2.net.bell.ca (64.230.125.231)  18.034 ms
 7  be4331.ccr21.sea02.atlas.cogentco.com (38.104.126.81)  18.793 ms
 8  be2085.ccr21.slc01.atlas.cogentco.com (154.54.2.198)  39.382 ms
 9  be2126.ccr21.den01.atlas.cogentco.com (154.54.25.65)  50.002 ms
10  be2128.ccr21.mci01.atlas.cogentco.com (154.54.25.174)  60.911 ms
11  be2157.ccr42.ord01.atlas.cogentco.com (154.54.6.118)  74.769 ms
12  be2185.ccr22.cle04.atlas.cogentco.com (154.54.43.178)  81.634 ms
13  be2482.ccr41.jfk02.atlas.cogentco.com (154.54.27.158)  93.691 ms
14  be2490.ccr42.lon13.atlas.cogentco.com (154.54.42.86)  175.340 ms
15  be2163.ccr22.lon01.atlas.cogentco.com (130.117.50.201)  170.940 ms
16  be2417.rcr11.b015533-1.lon01.atlas.cogentco.com (154.54.38.14)  171.315 ms
17  149.14.80.210 (149.14.80.210)  175.934 ms
18  ae1-1001-cpt1-ir1-i.tenet.ac.za (196.32.209.170)  314.868 ms
19  be4-cpt1-p1.tenet.ac.za (155.232.6.65)  316.861 ms
20  te0-0-0-1-cpt2-p1-n.tenet.ac.za (155.232.6.190)  318.349 ms
21  be1-cpt2-pe2.tenet.ac.za (155.232.6.233)  321.887 ms
22  155.232.32.14 (155.232.32.14)  318.232 ms
23  *
24  *
25  *
26  *
27  *
28  *
29  *
30  *
Conduct another search