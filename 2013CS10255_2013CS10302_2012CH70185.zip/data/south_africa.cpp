http://services.truteq.com/cgi-bin/nph-traceroute


Traceroute

Back to the Truteq Looking Glass (ping, traceroute, DNS lookup and NTP server checking)
Result for traceroute to 129.132.19.216:

traceroute to 129.132.19.216 (129.132.19.216), 30 hops max, 38 byte packets
 1  cisrb1-net109-64.posix.co.za (160.124.109.126)  0.347 ms  0.315 ms  0.195 ms
 2  cisldn1-cisrbc1.posix.co.za (160.124.1.2)  168.884 ms  168.991 ms  168.843 ms
 3  gi8-14.mag02.lon02.atlas.cogentco.com (149.6.149.9)  168.879 ms  168.943 ms  169.023 ms
 4  te0-7-0-7.ccr21.lon02.atlas.cogentco.com (154.54.60.149)  173.857 ms te0-0-0-9.ccr21.lon02.atlas.cogentco.com (154.54.60.145)  169.435 ms te0-7-0-7.ccr21.lon02.atlas.cogentco.com (154.54.60.149)  169.246 ms
 5  be2329.ccr22.lon01.atlas.cogentco.com (130.117.49.89)  169.917 ms be2328.ccr21.lon01.atlas.cogentco.com (130.117.49.85)  170.716 ms be2329.ccr22.lon01.atlas.cogentco.com (130.117.49.89)  169.411 ms
 6  be2178.ccr42.lon13.atlas.cogentco.com (130.117.50.206)  169.713 ms be2163.ccr41.lon13.atlas.cogentco.com (130.117.50.202)  172.883 ms  169.807 ms
 7  be2489.ccr42.par01.atlas.cogentco.com (154.54.39.114)  194.118 ms  177.500 ms  177.118 ms
 8  be2296.ccr21.zrh01.atlas.cogentco.com (130.117.3.58)  191.364 ms be2295.ccr21.zrh01.atlas.cogentco.com (130.117.3.54)  191.190 ms be2296.ccr21.zrh01.atlas.cogentco.com (130.117.3.58)  191.422 ms
 9  te8-4.mag01.zrh01.atlas.cogentco.com (154.54.38.254)  190.721 ms  190.661 ms  190.603 ms
10  te0-0-1-0.rcr11.bsl01.atlas.cogentco.com (130.117.2.146)  192.619 ms  192.467 ms  202.585 ms
11  149.6.34.6 (149.6.34.6)  248.101 ms  192.076 ms  211.078 ms
12  swiEZ1-10GE-3-1.switch.ch (130.59.37.105)  193.624 ms  191.566 ms  371.485 ms
13  swiEZ3-B3.switch.ch (130.59.36.34)  192.104 ms  192.018 ms  191.864 ms
14  rou-gw-rz-tengig-to-switch.ethz.ch (192.33.92.1)  191.868 ms  191.770 ms  191.860 ms
15  rou-fw-rz-rz-gw.ethz.ch (192.33.92.169)  251.072 ms  191.807 ms  191.620 ms
16  * * *
17  * * *
18  * * *
19  * * *
20  * * *
21  * * *
22  * * *
23  * * *
24  * * *
25  * * *
26  * * *
27  * * *
28  * * *
29  * * *
30  * * *

Completed in 234.35 seconds, 0% cpu



Traceroute

Back to the Truteq Looking Glass (ping, traceroute, DNS lookup and NTP server checking)
Result for traceroute to 103.27.9.20:

traceroute to 103.27.9.20 (103.27.9.20), 30 hops max, 38 byte packets
 1  cisrb1-net109-64.posix.co.za (160.124.109.126)  0.283 ms  0.359 ms  0.185 ms
 2  cisldn1-cisrbc1.posix.co.za (160.124.1.2)  170.620 ms  171.229 ms  168.807 ms
 3  gi8-14.mag02.lon02.atlas.cogentco.com (149.6.149.9)  244.820 ms  203.480 ms  196.815 ms
 4  te0-7-0-7.ccr21.lon02.atlas.cogentco.com (154.54.60.149)  169.839 ms te0-0-0-9.ccr21.lon02.atlas.cogentco.com (154.54.60.145)  169.206 ms te0-7-0-7.ccr21.lon02.atlas.cogentco.com (154.54.60.149)  169.729 ms
 5  be2328.ccr21.lon01.atlas.cogentco.com (130.117.49.85)  169.486 ms  169.458 ms  169.561 ms
 6  tata.lon01.atlas.cogentco.com (130.117.15.178)  227.541 ms  218.440 ms  173.596 ms
 7  if-17-2.tcore1.L78-London.as6453.net (80.231.130.129)  192.842 ms  190.730 ms  190.592 ms
 8  if-2-2.tcore2.L78-London.as6453.net (80.231.131.1)  190.641 ms  197.539 ms  206.337 ms
 9  if-9-2.tcore2.WYN-Marseille.as6453.net (80.231.200.13)  190.620 ms  190.543 ms  191.615 ms
10  80.231.200.30 (80.231.200.30)  287.052 ms  286.799 ms  284.786 ms
11  * * *
12  14.140.210.22.static-Delhi-vsnl.net.in (14.140.210.22)  317.499 ms  317.385 ms  317.540 ms
13  * * *
14  * * *
15  * * *
16  * * *
17  * * *
18  * * *
19  * * *
20  * * *
21  * * *
22  * * *
23  * * *
24  * * *
25  * * *
26  * * *
27  * * *
28  * * *
29  * * *
30  * * *

Completed in 291.64 seconds, 0% cpu


Traceroute

Back to the Truteq Looking Glass (ping, traceroute, DNS lookup and NTP server checking)
Result for traceroute to 129.97.208.23:

traceroute to 129.97.208.23 (129.97.208.23), 30 hops max, 38 byte packets
 1  cisrb1-net109-64.posix.co.za (160.124.109.126)  0.298 ms  0.343 ms  0.190 ms
 2  cisldn1-cisrbc1.posix.co.za (160.124.1.2)  168.859 ms  169.017 ms  168.834 ms
 3  gi8-14.mag02.lon02.atlas.cogentco.com (149.6.149.9)  168.819 ms  168.938 ms  168.840 ms
 4  te0-0-0-9.ccr21.lon02.atlas.cogentco.com (154.54.60.145)  169.345 ms te0-7-0-7.ccr21.lon02.atlas.cogentco.com (154.54.60.149)  169.455 ms te0-0-0-9.ccr21.lon02.atlas.cogentco.com (154.54.60.145)  169.182 ms
 5  be2329.ccr22.lon01.atlas.cogentco.com (130.117.49.89)  169.904 ms be2328.ccr21.lon01.atlas.cogentco.com (130.117.49.85)  169.691 ms be2329.ccr22.lon01.atlas.cogentco.com (130.117.49.89)  169.397 ms
 6  be2178.ccr42.lon13.atlas.cogentco.com (130.117.50.206)  169.693 ms be2494.ccr42.lon13.atlas.cogentco.com (154.54.39.130)  169.643 ms  169.925 ms
 7  be2491.ccr22.lpl01.atlas.cogentco.com (154.54.39.117)  176.574 ms  176.751 ms  176.323 ms
 8  be2385.ccr22.ymq02.atlas.cogentco.com (154.54.44.141)  246.257 ms  247.460 ms  245.990 ms
 9  be2093.ccr22.yyz02.atlas.cogentco.com (154.54.44.105)  258.069 ms  260.347 ms  254.058 ms
10  university_of_waterloo.demarc.cogentco.com (38.99.202.214)  259.993 ms  258.908 ms  258.733 ms
11  * * *
12  * * *
13  * * *
14  * * *
15  wms.uwaterloo.ca (129.97.208.23)  259.584 ms  259.457 ms  259.325 ms
16  * * *
17  wms.uwaterloo.ca (129.97.208.23)  259.546 ms  258.948 ms  259.578 ms
18  * * *
19  wms.uwaterloo.ca (129.97.208.23)  259.559 ms  259.652 ms  259.338 ms
20  * * *
21  wms.uwaterloo.ca (129.97.208.23)  259.515 ms  259.672 ms  259.827 ms
22  * * *
23  wms.uwaterloo.ca (129.97.208.23)  278.667 ms  260.709 ms  259.568 ms
24  * * *
25  wms.uwaterloo.ca (129.97.208.23)  259.865 ms  259.195 ms  259.792 ms
26  * * *
27  wms.uwaterloo.ca (129.97.208.23)  259.812 ms  259.515 ms  259.281 ms
28  * * *
29  wms.uwaterloo.ca (129.97.208.23)  266.798 ms  259.865 ms  259.575 ms
30  * * *

Completed in 192.10 seconds, 0% cpu


Traceroute

Back to the Truteq Looking Glass (ping, traceroute, DNS lookup and NTP server checking)
Result for traceroute to 137.158.158.44:

traceroute to 137.158.158.44 (137.158.158.44), 30 hops max, 38 byte packets
 1  cisrb1-net109-64.posix.co.za (160.124.109.126)  0.397 ms  0.311 ms  0.180 ms
 2  cisrb3.posix.co.za (160.124.2.3)  1.976 ms  2.088 ms  1.949 ms
 3  tenet.jinx.net.za (196.223.14.33)  2.232 ms  2.141 ms  2.196 ms
 4  te4-1-jnb1-pe1-n.tenet.ac.za (155.232.6.109)  2.242 ms  2.354 ms  2.208 ms
 5  te0-7-0-2-102-cpt2-pe2.tenet.ac.za (155.232.15.135)  20.467 ms  20.325 ms  20.685 ms
 6  unknown.uni.net.za (155.232.6.232)  22.220 ms  22.780 ms  23.934 ms
 7  te0-0-0-3-cpt2-p1-n.tenet.ac.za (155.232.6.213)  19.469 ms  19.052 ms  18.938 ms
 8  155.232.27.78 (155.232.27.78)  21.961 ms  21.957 ms  21.910 ms
 9  * * *
10  * * *
11  * * *
12  * * *
13  * * *
14  * * *
15  * * *
16  * * *
17  * * *
18  * * *
19  * * *
20  * * *
21  * * *
22  * * *
23  * * *
24  * * *
25  * * *
26  * * *
27  * * *
28  * * *
29  * * *
30  * * *

Completed in 330.62 seconds, 0% cpu


