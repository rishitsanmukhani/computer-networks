Ergebnis: traceroute to 129.132.19.216
1 213.90.34.1 (213.90.34.1) 0.478 ms 0.503 ms 0.443 ms 
2 213.90.1.20 (213.90.1.20) 11.110 ms 1.375 ms 0.884 ms 
3 wat1-15-93.net.uta.at (62.218.15.93) 0.883 ms 0.817 ms 0.685 ms 
4 c76wat2-tge12-1.net.uta.at (212.152.192.166) 54.021 ms 5.524 ms 2.028 ms 
5 * * * 
6 wen3-core-2.bundle-ether1.tele2.net (130.244.205.72) 2.353 ms 10.505 ms 1.852 ms 
7 wen3-peer-2.ae3-unit0.tele2.net (130.244.74.245) 1.180 ms 1.089 ms 1.034 ms 
8 win-b4-link.telia.net (213.248.76.245) 2.403 ms 3.614 ms 3.136 ms 
9 win-bb2-link.telia.net (62.115.136.242) 1.739 ms 1.737 ms 1.975 ms 
10 ffm-bb2-link.telia.net (213.155.131.212) 13.920 ms 13.898 ms 13.670 ms 
11 zch-b2-link.telia.net (62.115.142.107) 24.844 ms zch-b2-link.telia.net (62.115.142.111) 25.207 ms zch-b2-link.telia.net (62.115.142.107) 24.830 ms 
12 dante-ic-308868-zch-b2.c.telia.net (213.248.79.190) 105.071 ms 50.958 ms 71.929 ms 
13 swiIX2-10GE-1-4.switch.ch (130.59.36.42) 293.265 ms 89.797 ms 75.582 ms 
14 swiEZ2-P1.switch.ch (130.59.36.249) 34.243 ms 28.997 ms 28.436 ms 
15 swiEZ1-P2.switch.ch (130.59.36.25) 28.652 ms 28.576 ms 28.539 ms 
16 swiEZ3-B3.switch.ch (130.59.36.34) 29.245 ms 29.068 ms 29.109 ms 
17 rou-gw-rz-tengig-to-switch.ethz.ch (192.33.92.1) 29.229 ms 30.240 ms 28.922 ms 
18 rou-fw-rz-rz-gw.ethz.ch (192.33.92.169) 29.305 ms 29.405 ms 31.797 ms 
19 * * * 
20 * * * 
21 * * * 
22 * * * 
23 * * * 
24 * * * 
25 * * * 
26 * * * 
27 * * * 
28 * * * 
29 * * * 
30 * * * 


Ergebnis: traceroute to 129.97.208.23
1 213.90.34.1 (213.90.34.1) 0.471 ms 0.470 ms 0.365 ms 
2 213.90.1.20 (213.90.1.20) 0.718 ms 0.760 ms 0.649 ms 
3 wat1-15-93.net.uta.at (62.218.15.93) 1.223 ms 0.706 ms 0.755 ms 
4 c76wat2-tge12-1.net.uta.at (212.152.192.166) 1.154 ms 1.456 ms 0.928 ms 
5 * * * 
6 wen3-core-2.bundle-ether1.tele2.net (130.244.205.72) 1.625 ms 1.456 ms 1.516 ms 
7 wen3-peer-2.ae3-unit0.tele2.net (130.244.74.245) 1.092 ms 1.217 ms 1.190 ms 
8 peer-as174.wen3.tele2.net (130.244.200.66) 1.712 ms 1.816 ms 1.854 ms 
9 be2223.ccr22.muc03.atlas.cogentco.com (130.117.49.137) 13.669 ms 13.773 ms 13.775 ms 
10 be2229.ccr42.fra03.atlas.cogentco.com (154.54.38.57) 13.500 ms 13.823 ms 13.568 ms 
11 be2262.ccr42.ams03.atlas.cogentco.com (154.54.37.33) 20.296 ms 20.260 ms 20.421 ms 
12 be2183.ccr22.lpl01.atlas.cogentco.com (154.54.58.69) 30.224 ms 30.203 ms 30.200 ms 
13 be2385.ccr22.ymq02.atlas.cogentco.com (154.54.44.141) 106.643 ms 107.344 ms 106.075 ms 
14 be2093.ccr22.yyz02.atlas.cogentco.com (154.54.44.105) 117.720 ms 116.954 ms 116.812 ms 
15 university_of_waterloo.demarc.cogentco.com (38.99.202.214) 122.267 ms 122.932 ms 144.760 ms 
16 * * * 
17 * * * 
18 * * * 
19 * * * 
20 wms.uwaterloo.ca (129.97.208.23) 119.842 ms 120.224 ms 119.807 ms 



Ergebnis: traceroute to 103.27.9.20
1 213.90.34.1 (213.90.34.1) 0.584 ms 0.488 ms 0.438 ms 
2 213.90.1.20 (213.90.1.20) 0.865 ms 0.930 ms 0.800 ms 
3 wat1-15-93.net.uta.at (62.218.15.93) 14.010 ms 0.929 ms 0.834 ms 
4 c76wat2-tge12-1.net.uta.at (212.152.192.166) 0.992 ms 1.065 ms 0.863 ms 
5 * * * 
6 fra36-core-1.bundle-ether7.tele2.net (130.244.206.28) 13.082 ms 13.141 ms 13.059 ms 
7 fra36-peer-1.ae3-unit0.tele2.net (130.244.64.187) 12.667 ms 12.788 ms 13.835 ms 
8 peer-as6453.fra36.tele2.net (130.244.200.162) 19.950 ms 22.946 ms 13.011 ms 
9 if-4-2.tcore2.FNM-Frankfurt.as6453.net (195.219.87.17) 26.131 ms 26.372 ms 26.449 ms 
MPLS Label=433818 CoS=6 TTL=1 S=0 
10 if-7-2.tcore2.WYN-Marseille.as6453.net (80.231.200.77) 26.164 ms 25.995 ms 26.090 ms 
11 80.231.200.30 (80.231.200.30) 121.574 ms 121.709 ms 127.657 ms 
12 * * * 
13 14.140.210.22.static-Delhi-vsnl.net.in (14.140.210.22) 163.469 ms 163.284 ms 163.912 ms 
14 * * * 
15 * * * 
16 * * * 
17 103.27.9.20 (103.27.9.20) 163.472 ms 162.302 ms 162.213 ms 
18 103.27.9.20 (103.27.9.20) 165.588 ms 162.468 ms 162.206 ms 
19 103.27.9.20 (103.27.9.20) 162.309 ms 162.891 ms 162.571 ms 



Ergebnis: traceroute to 137.158.158.44
1 213.90.34.1 (213.90.34.1) 0.531 ms 0.488 ms 0.429 ms 
2 213.90.1.20 (213.90.1.20) 0.931 ms 0.820 ms 0.765 ms 
3 wat1-15-93.net.uta.at (62.218.15.93) 1.087 ms 0.872 ms 0.781 ms 
4 c76wat2-tge12-1.net.uta.at (212.152.192.166) 1.448 ms 1.121 ms 0.906 ms 
5 * * * 
6 wen3-core-2.bundle-ether1.tele2.net (130.244.205.72) 1.855 ms 1.453 ms 1.328 ms 
7 wen3-peer-2.ae3-unit0.tele2.net (130.244.74.245) 1.617 ms 1.440 ms 1.427 ms 
8 peer-as174.wen3.tele2.net (130.244.200.66) 1.873 ms 1.735 ms 1.825 ms 
9 be2223.ccr22.muc03.atlas.cogentco.com (130.117.49.137) 13.598 ms 14.228 ms 13.442 ms 
10 be2229.ccr42.fra03.atlas.cogentco.com (154.54.38.57) 13.834 ms 14.925 ms 13.961 ms 
11 be2262.ccr42.ams03.atlas.cogentco.com (154.54.37.33) 20.692 ms 20.429 ms 20.677 ms 
12 be2312.ccr21.ams04.atlas.cogentco.com (154.54.74.94) 21.001 ms 20.857 ms 22.805 ms 
13 149.11.38.190 (149.11.38.190) 20.383 ms 22.027 ms 20.339 ms 
14 xe0-0-0-0-ua-uk-ldn1-01.ubuntunet.net (196.32.209.49) 25.930 ms 26.096 ms 26.157 ms 
15 ae1-1001-cpt1-ir1-i.tenet.ac.za (196.32.209.170) 169.455 ms 169.331 ms 169.479 ms 
16 be4-cpt1-p1.tenet.ac.za (155.232.6.65) 174.807 ms 173.359 ms 177.055 ms 
MPLS Label=16024 CoS=6 TTL=255 S=0 
MPLS Label=16056 CoS=2 TTL=255 S=0 
17 te0-0-0-1-cpt2-p1-n.tenet.ac.za (155.232.6.190) 174.568 ms 175.727 ms 175.258 ms 
MPLS Label=16055 CoS=6 TTL=255 S=0 
MPLS Label=16056 CoS=2 TTL=255 S=0 
18 be1-cpt2-pe2.tenet.ac.za (155.232.6.233) 172.364 ms 172.354 ms 207.776 ms 
MPLS Label=16056 CoS=6 TTL=255 S=0 
19 155.232.32.14 (155.232.32.14) 172.671 ms 171.853 ms 172.364 ms 
20 * * * 
21 * * * 
22 * * * 
23 * * * 
24 * * * 
25 * * * 
26 * * * 
27 * * * 
28 * * * 
29 * * * 
30 * * * 
