http://traceroute.dsvr.co.uk/cgi-bin/trace.pl?t=129.132.19.216


Traceroute Gateway

at Designer Servers Ltd
Version: v1.2 Date: 14-Oct-2001 Copyright: (c) Gabor Szabo @ Multiple Traceroute Gateway
Other Traceroute Gateways

 1  host-212-69-210-4.no-dns.as5587.net (212.69.210.4)  0.000 ms  0.000 ms  0.000 ms
 2  host-213-253-141-28.no-dns.as5587.net (213.253.141.28)  0.000 ms  0.000 ms  10.000 ms
 3  v1124.core1.lon1.he.net (216.66.83.113)  10.000 ms  10.000 ms  20.001 ms
 4  10ge2-9.core1.lon2.he.net (72.52.92.222)  0.000 ms  10.000 ms  10.000 ms
 5  100ge9-2.core1.tor1.he.net (184.105.80.38)  20.001 ms  20.000 ms  10.001 ms
 6  10ge3-1.core1.zrh1.he.net (72.52.92.30)  40.000 ms  30.001 ms  40.000 ms
 7  swiIX1-10GE-1-2.switch.ch (194.42.48.11)  20.001 ms  30.001 ms  50.000 ms
 8  swiIX2-10GE-1-4.switch.ch (130.59.36.42)  30.001 ms  20.000 ms  100.002 ms
 9  swiEZ2-P1.switch.ch (130.59.36.249)  30.000 ms  20.000 ms  30.001 ms
10  swiEZ1-P2.switch.ch (130.59.36.25)  30.000 ms  30.000 ms  30.000 ms
11  swiEZ3-B3.switch.ch (130.59.36.34)  20.001 ms  30.001 ms  30.000 ms
12  rou-gw-rz-tengig-to-switch.ethz.ch (192.33.92.1)  30.001 ms  30.001 ms  30.000 ms
13  rou-fw-rz-rz-gw.ethz.ch (192.33.92.169)  20.000 ms  30.000 ms  30.001 ms
14  * * *
15  * * *
16  * * *
17  * * *
18  * * *
19  * * *
20  * * *
21  * * *
22  * * *
23  * * *
24  * * *
25  * * *
26  * * *
27  * * *
28  * * *
29  * * *
30  * * *
Please type in the IP address or the full name of the machine you want to Traceroute to


Traceroute Gateway

at Designer Servers Ltd
Version: v1.2 Date: 14-Oct-2001 Copyright: (c) Gabor Szabo @ Multiple Traceroute Gateway
Other Traceroute Gateways

 1  host-212-69-210-4.no-dns.as5587.net (212.69.210.4)  0.000 ms  0.000 ms  0.000 ms
 2  host-213-253-141-28.no-dns.as5587.net (213.253.141.28)  0.000 ms  0.000 ms  0.000 ms
 3  v1124.core1.lon1.he.net (216.66.83.113)  10.000 ms  10.000 ms  10.000 ms
 4  ldn-b5-link.telia.net (213.248.93.81)  10.000 ms  10.000 ms  10.000 ms
 5  tata-ic-300410-ldn-b5.c.telia.net (62.115.9.174)  10.000 ms  10.000 ms  10.000 ms
 6  if-15-2.tcore2.L78-London.as6453.net (80.231.131.117)  20.001 ms  30.001 ms  30.000 ms
 7  if-9-2.tcore2.WYN-Marseille.as6453.net (80.231.200.13)  30.001 ms  30.000 ms  20.001 ms
 8  80.231.200.30 (80.231.200.30)  130.002 ms  120.002 ms  130.002 ms
 9  * * *
10  14.140.210.22.static-Delhi-vsnl.net.in (14.140.210.22)  150.002 ms  150.002 ms  150.002 ms
11  * * *
12  * * *
13  * * *
14  * * *
15  * * *
16  * * *
17  * * *
18  * * *
19  * * *
20  * * *
21  * * *
22  * * *
23  * * *
24  * * *
25  * * *
26  * * *
27  * * *
28  * * *
29  * * *
30  * * *
Please type in the IP address or the full name of the machine you want to Traceroute to



Traceroute Gateway

at Designer Servers Ltd
Version: v1.2 Date: 14-Oct-2001 Copyright: (c) Gabor Szabo @ Multiple Traceroute Gateway
Other Traceroute Gateways

 1  host-212-69-210-4.no-dns.as5587.net (212.69.210.4)  0.000 ms  0.000 ms  0.000 ms
 2  host-213-253-141-28.no-dns.as5587.net (213.253.141.28)  0.000 ms  10.001 ms  0.000 ms
 3  v1124.core1.lon1.he.net (216.66.83.113)  0.000 ms  10.000 ms  10.000 ms
 4  10ge2-9.core1.lon2.he.net (72.52.92.222)  10.000 ms  10.000 ms  10.000 ms
 5  100ge1-1.core1.nyc4.he.net (72.52.92.166)  70.001 ms  80.001 ms  70.001 ms
 6  10ge5-1.core1.nyc6.he.net (184.105.222.82)  70.001 ms  80.001 ms  70.002 ms
 7  xe1-1-1.gw2-nyc.bb.allstream.net (198.32.160.84)  80.001 ms  80.001 ms  70.001 ms
 8  10ge4-11.hcap9-tor.bb.allstream.net (199.212.169.202)  80.001 ms  90.001 ms  90.002 ms
 9  10ge4-11.hcap9-tor.bb.allstream.net (199.212.169.202)  80.001 ms  90.001 ms  80.001 ms
10  216-191-167-38.dedicated.allstream.net (216.191.167.38)  90.002 ms  90.001 ms  90.002 ms
11  * * *
12  * * *
13  * * *
14  * * *
15  wms.uwaterloo.ca (129.97.208.23)  80.001 ms  90.002 ms  90.001 ms
16  * * *
17  wms.uwaterloo.ca (129.97.208.23)  80.002 ms  90.001 ms  80.001 ms
18  * * *
19  wms.uwaterloo.ca (129.97.208.23)  80.001 ms  90.001 ms  90.002 ms
20  * * *
21  wms.uwaterloo.ca (129.97.208.23)  80.001 ms  90.002 ms  80.001 ms
22  * * *
23  wms.uwaterloo.ca (129.97.208.23)  80.001 ms  80.002 ms  90.001 ms
24  * * *
25  wms.uwaterloo.ca (129.97.208.23)  80.001 ms  90.002 ms  90.001 ms
26  * * *
27  wms.uwaterloo.ca (129.97.208.23)  80.002 ms  90.001 ms  90.001 ms
28  * * *
29  wms.uwaterloo.ca (129.97.208.23)  80.001 ms  90.001 ms  90.002 ms
30  * * *
Please type in the IP address or the full name of the machine you want to Traceroute to



Traceroute Gateway

at Designer Servers Ltd
Version: v1.2 Date: 14-Oct-2001 Copyright: (c) Gabor Szabo @ Multiple Traceroute Gateway
Other Traceroute Gateways

 1  host-212-69-210-4.no-dns.as5587.net (212.69.210.4)  10.000 ms  0.000 ms  0.000 ms
 2  host-213-253-141-28.no-dns.as5587.net (213.253.141.28)  0.000 ms  0.000 ms  0.000 ms
 3  v1124.core1.lon1.he.net (216.66.83.113)  10.000 ms  10.000 ms  10.000 ms
 4  10ge2-9.core1.lon2.he.net (72.52.92.222)  10.000 ms  20.001 ms  10.000 ms
 5  ubuntunet-linx-lnd.tenet.ac.za (195.66.225.31)  10.000 ms  20.001 ms  10.000 ms
 6  te-3-3.ldn1.uk.ubuntunet.net (196.32.209.77)  10.000 ms  0.000 ms  10.000 ms
 7  ae1-1001-cpt1-ir1-i.tenet.ac.za (196.32.209.170)  150.002 ms  150.002 ms  150.002 ms
 8  be4-cpt1-p1.tenet.ac.za (155.232.6.65)  160.003 ms  160.002 ms  150.003 ms
 9  te0-0-0-1-cpt2-p1-n.tenet.ac.za (155.232.6.190)  160.002 ms  160.002 ms  160.002 ms
10  te0-12-0-6-cpt2-p1-n.tenet.ac.za (155.232.6.233)  150.003 ms  150.002 ms  150.003 ms
11  155.232.32.14 (155.232.32.14)  150.002 ms  150.002 ms  150.002 ms
12  * * *
13  * * *
14  * * *
15  * * *
16  * * *
17  * * *
18  * * *
19  * * *
20  * * *
21  * * *
22  * * *
23  * * *
24  * * *
25  * * *
26  * * *
27  * * *
28  * * *
29  * * *
30  * * *
Please type in the IP address or the full name of the machine you want to Traceroute to
